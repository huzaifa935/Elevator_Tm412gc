#ifndef KEYPAD_H_
#define KEYPAD_H_

#include <stdint.h>

/* Optional debugger watch variables, defined once in keypad.c. */
extern volatile uint8_t keypad_value;
extern volatile uint32_t key_events;

void Keypad_Init(void);

/*
 * Call repeatedly from the main loop. This function does not wait.
 * Returns 1 and writes *key when a new key has been identified.
 * Returns 0 otherwise; *key is left unchanged.
 *
 * Keys 0-9 are numeric values. '*' and '#' are character values.
 * One event is reported per press, followed by release debouncing.
 */
uint8_t Keypad_GetKey(uint8_t *key);

/* Connect this function to the GPIO Port B entry in the vector table. */
void GPIOPortB_Handler(void);

#endif /* KEYPAD_H_ */
