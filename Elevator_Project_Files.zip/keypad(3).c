#include "keypad.h"
#include "systick.h"
#include "tm4c123gh6pm.h"

#define ROW_MASK        0x0FU
#define COL_MASK        0x07U
#define SAMPLE_MS       10U
#define STABLE_SAMPLES  4U
#define SETTLE_MS       1U

/*
 * button_phase:
 * 0 = Idle
 * 1 = Debounce press
 * 2 = Scan columns
 * 3 = Debounce release
 */
static volatile uint8_t button_phase = 0U;
static volatile uint32_t keypad_status = 0U;
static volatile uint32_t count_down = 0U;
static volatile uint32_t count_up = 0U;

/* Watch these variables in the debugger. */
volatile uint8_t keypad_value = 0U;
volatile uint32_t key_events = 0U;

/* Debounce counters. */
static uint8_t down = 0U;
static uint8_t up = 0U;

/* Column pin masks. */
static const uint8_t col[3] = {
    0x01U, 0x02U, 0x04U
};

/* Scanner variables, used only by the foreground keypad code. */
static uint8_t row_found = 0U;
static uint8_t count_col = 0U;
static uint8_t waiting_for_settle = 0U;
static uint32_t column_start_time = 0U;

/* Private functions: only keypad.c calls these. */
static uint8_t keypad_scan(uint32_t status);

static uint8_t deboucing(volatile uint32_t *data,
                        volatile uint32_t *icr,
                        volatile uint32_t *imr,
                        uint32_t position,
                        volatile uint8_t *button_press,
                        uint8_t *down,
                        uint8_t *up);

void Keypad_Init(void)
{
    /* Enable clocks for Ports B and E. */
    SYSCTL_RCGCGPIO_R |= 0x12U;

    while ((SYSCTL_PRGPIO_R & 0x12U) != 0x12U)
    {
    }

    /* Mask row interrupts during configuration. */
    GPIO_PORTB_IM_R &= ~ROW_MASK;

    /* PB0-PB3: row inputs with pull-ups. */
    GPIO_PORTB_AFSEL_R &= ~ROW_MASK;
    GPIO_PORTB_AMSEL_R &= ~ROW_MASK;
    GPIO_PORTB_PCTL_R &= ~0x0000FFFFU;
    GPIO_PORTB_DIR_R &= ~ROW_MASK;
    GPIO_PORTB_DEN_R |= ROW_MASK;
    GPIO_PORTB_PDR_R &= ~ROW_MASK;
    GPIO_PORTB_PUR_R |= ROW_MASK;

    /* PE0-PE2: column pins without pull resistors. */
    GPIO_PORTE_AFSEL_R &= ~COL_MASK;
    GPIO_PORTE_AMSEL_R &= ~COL_MASK;
    GPIO_PORTE_PCTL_R &= ~0x00000FFFU;
    GPIO_PORTE_PUR_R &= ~COL_MASK;
    GPIO_PORTE_PDR_R &= ~COL_MASK;
    GPIO_PORTE_DEN_R |= COL_MASK;

    /* Idle: all columns drive LOW. */
    GPIO_PORTE_DIR_R |= COL_MASK;
    GPIO_PORTE_DATA_R &= ~COL_MASK;

    /* Falling-edge row interrupts. */
    GPIO_PORTB_IS_R &= ~ROW_MASK;
    GPIO_PORTB_IBE_R &= ~ROW_MASK;
    GPIO_PORTB_IEV_R &= ~ROW_MASK;
    GPIO_PORTB_ICR_R = ROW_MASK;

    /* Enable GPIO Port B interrupt in NVIC, then unmask the rows. */
    NVIC_EN0_R = (1U << 1);
    GPIO_PORTB_IM_R |= ROW_MASK;
}

void GPIOPortB_Handler(void)
{
    uint32_t status = GPIO_PORTB_MIS_R & ROW_MASK;

    if (status == 0U)
    {
        return;
    }

    /* Mask all keypad rows while processing. */
    GPIO_PORTB_IM_R &= ~ROW_MASK;
    GPIO_PORTB_ICR_R = status;
    keypad_status = status;
    count_down = count_ms;
    count_up = count_down;

    /* Multiple rows: wait for all keys to release. */
    if ((status & (status - 1U)) != 0U)
    {
        button_phase = 3U;
    }
    else
    {
        button_phase = 1U;
    }
}

uint8_t Keypad_GetKey(uint8_t *key)
{

    if (deboucing(&GPIO_PORTB_DATA_R,
                 &GPIO_PORTB_ICR_R,
                 &GPIO_PORTB_IM_R,
                 keypad_status,
                 &button_phase,
                 &down,
                 &up) == 1U)
    {
        *key = keypad_value;
         key_events++;
         return 1;
    }
    return 0;
}

/* Returns 1 only when a new key is identified. */
static uint8_t deboucing(volatile uint32_t *data,
                        volatile uint32_t *icr,
                        volatile uint32_t *imr,
                        uint32_t position,
                        volatile uint8_t *button_press,
                        uint8_t *down,
                        uint8_t *up)
{
    uint32_t low_rows;
    uint8_t scan_result;
    uint8_t rearm = 0U;

    /* Phase 1: debounce press. */
    if (*button_press == 1U)
    {
        if ((uint32_t)(count_ms - count_down) >= SAMPLE_MS)
        {
            count_down = count_ms;

            if ((*data & position) == 0U)
            {
                *up = 0U;
                (*down)++;

                if (*down >= STABLE_SAMPLES)
                {
                    *down = 0U;
                    *button_press = 2U;
                }
            }
            else
            {
                *down = 0U;
                (*up)++;

                if (*up >= STABLE_SAMPLES)
                {
                    rearm = 1U;
                }
            }
        }
    }
    /* Phase 2: scan columns. */
    else if (*button_press == 2U)
    {
        scan_result = keypad_scan(position);

        if (scan_result != 0U)
        {
            *button_press = 3U;
            *up = 0U;
            count_up = count_ms;

            if (scan_result == 1U)
            {
                return 1U;
            }
        }
    }
    /* Phase 3: debounce release. */
    else if (*button_press == 3U)
    {
        if ((uint32_t)(count_ms - count_up) >= SAMPLE_MS)
        {
            if ((*data & ROW_MASK) == ROW_MASK)
            {
                (*up)++;

                if (*up >= STABLE_SAMPLES)
                {
                    rearm = 1U;
                }
            }
            else
            {
                *up = 0U;
            }
        }
    }

    if (rearm != 0U)
    {
        *down = 0U;
        *up = 0U;
        keypad_status = 0U;
        *button_press = 0U;

        *icr = ROW_MASK;

        low_rows = (~(*data)) & ROW_MASK;

        if (low_rows != 0U)
        {
            keypad_status = low_rows;
            count_down = count_ms;
            count_up = count_ms;

            if ((low_rows & (low_rows - 1U)) != 0U)
            {
                *button_press = 3U;
            }
            else
            {
                *button_press = 1U;
            }
        }
        else
        {
            *imr |= ROW_MASK;
        }
    }

    return 0U;
}
/*
 * Returns:
 * 0 = Scanning in progress
 * 1 = Key identified
 * 8 = No match or invalid row mask
 */
static uint8_t keypad_scan(uint32_t status)
{
    static const uint8_t keys[4][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9},
        {'*', 0, '#'}
    };
    static uint8_t row = 0U;

    if (row_found == 0U)
    {
        switch (status)
        {
            case 0x01U: row = 0U; break;
            case 0x02U: row = 1U; break;
            case 0x04U: row = 2U; break;
            case 0x08U: row = 3U; break;

            default:
                count_col = 0U;
                waiting_for_settle = 0U;
                GPIO_PORTE_DIR_R |= COL_MASK;
                GPIO_PORTE_DATA_R &= ~COL_MASK;
                return 0;
        }

        row_found = 1U;
        count_col = 0U;
        waiting_for_settle = 0U;
    }

    if (count_col >= 3U)
    {
        count_col = 0U;
        row_found = 0U;
        waiting_for_settle = 0U;
        GPIO_PORTE_DIR_R |= COL_MASK;
        GPIO_PORTE_DATA_R &= ~COL_MASK;
        return 0;
    }

    if (waiting_for_settle == 0U)
    {
        GPIO_PORTE_DIR_R &= ~COL_MASK;
        GPIO_PORTE_DIR_R |= col[count_col];
        GPIO_PORTE_DATA_R &= ~COL_MASK;

        column_start_time = count_ms;
        waiting_for_settle = 1U;
    }
    if ((uint32_t)(count_ms - column_start_time) <= 1)
    {
        return 0U;
    }
    waiting_for_settle = 0U;
    if ((GPIO_PORTB_DATA_R & status) == 0U)
    {
        keypad_value = keys[row][count_col];
        count_col = 0U;
        row_found = 0U;
        GPIO_PORTE_DIR_R |= COL_MASK;
        GPIO_PORTE_DATA_R &= ~COL_MASK;
        return 1U;
    }
    count_col++;
    return 0U;
}
