/*
 * sw1_sw2.h
 *
 *  Created on: Nov 7, 2026
 *      Author: 16022
 */

#ifndef SW1_SW2_H_
#define SW1_SW2_H_

#include <stdint.h>

#define SW1                 0x10U   /* PF4 */
#define SW2                 0x01U   /* PF0 */
#define DEBOUNCE_MS         10U
#define DEBOUNCE_SAMPLES    4U

/* Last measured hold duration, in milliseconds. Original spelling retained. */
extern volatile uint32_t diffrence_1;
extern volatile uint32_t diffrence_2;

/* Set after a debounced release. Application clears after reading duration. */
extern volatile uint8_t duration_ready_1;
extern volatile uint8_t duration_ready_2;

/* Set when a press candidate is rejected; cleared at the next press edge. */
extern volatile uint8_t short_pulse_1;
extern volatile uint8_t short_pulse_2;

/* Debugger: last Port F interrupt status; SW1=0x10, SW2=0x01, both=0x11. */
extern volatile uint32_t x;

void Buttons_Init(void);
void Buttons_Update(void);

/* Must be connected to the GPIO Port F entry in your startup vector table. */
void GPIOPortF_Handler(void);




#endif /* SW1_SW2_H_ */
