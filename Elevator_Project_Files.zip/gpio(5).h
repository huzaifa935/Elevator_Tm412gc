/*
 * gpio.h
 *
 *  Created on: Nov 4, 2026
 *      Author: 16022
 */

#ifndef GPIO_H_
#define GPIO_H_
#include "stdint.h"
#define RGB_OFF      0x00U
#define RGB_RED      0x02U
#define RGB_BLUE     0x04U
#define RGB_GREEN    0x08U
#define RGB_YELLOW   0x0AU
#define RGB_CYAN     0x0CU
#define RGB_MAGENTA  0x06U
#define RGB_WHITE    0x0EU

void RGB_Set(uint8_t color);
void blink_led(uint8_t color,uint8_t flag);
void Turn_on(uint8_t color);
void Turn_off(uint8_t color);

void PortF_init(void);


#endif /* GPIO_H_ */
