#ifndef Q_H
#define Q_H

#include <stdint.h>

#define STATE_Q_SIZE       8U
#define MAINTENANCE_Q_SIZE 2U
#define EMERGENCY_Q_SIZE   2U
#define INTERNAL_Q_SIZE    2U
#define QUEUE_EMPTY        'E'

/* Valid values: 1 through QUEUE_MAX_VALUE.
 * Increase this if your internal state IDs exceed 5 (maximum 255).
 * Queue capacities must be between 1 and 255.
 */
#define QUEUE_MAX_VALUE    6U

typedef struct
{
    uint8_t *arr;       /* Points to this queue's separate storage array. */
    uint8_t capacity;
    uint8_t head;       /* First occupied entry when count > 0. */
    uint8_t tail;       /* Next free slot when count < capacity. */
    uint8_t count;      /* Distinguishes empty and full. */
    uint8_t pending_reg[QUEUE_MAX_VALUE + 1U];
} queue_t;

/* Same underlying type, so the same functions accept either name. */
typedef queue_t state_q;
typedef queue_t remaing_state;

/* Defined once in corrected_queue.c; shared with files including this header. */
extern state_q sq;
extern remaing_state msq;
extern remaing_state esq;
extern remaing_state isq;

/* Return 1 when inserted. Return 0 for a full queue, an invalid value,
 * or a value equal to the last queued value.
 */
uint8_t insert_q(queue_t *q, uint8_t value);

/* Return 1 when the head was removed, or 0 when empty. */
uint8_t remove_head(queue_t *q);

/* Return 1 when the value is pending in this queue, or 0 otherwise. */
uint8_t search_element( queue_t *q, uint8_t value);

/* Remove the first matching value nearest to head, preserving order.
 * Return 1 when removed, or 0 when absent or invalid.
 */
uint8_t remove_the_element(queue_t *q, uint8_t value);

/* Fill unused storage with 'E' and reset the queue and pending counts. */
void clear_q(queue_t *q);

uint8_t read_head(queue_t *q);
uint8_t check_q(queue_t *q);

#endif /* CORRECTED_QUEUE_H */
