#include <stdint.h>
#include <string.h>
#include "q.h"
#define STATE_Q_SIZE       8U
#define MAINTENANCE_Q_SIZE 2U
#define EMERGENCY_Q_SIZE   2U
#define INTERNAL_Q_SIZE    2U
#define QUEUE_EMPTY        'E'


/* Separate storage for each queue. Unused slots contain 'E'.
 * These initializers fill the configured 8/2/2/2 slots. If changing a size,
 * adjust its initializer or call clear_q on that queue before first use.
 */
 uint8_t state_arr[STATE_Q_SIZE] = {
    'E', 'E', 'E', 'E',
    'E', 'E','E', 'E'
};
 uint8_t maintenance_arr[MAINTENANCE_Q_SIZE] = {
    'E', 'E'
};
 uint8_t emergency_arr[EMERGENCY_Q_SIZE] = {
    'E', 'E'
};
 uint8_t internal_arr[INTERNAL_Q_SIZE] = {
    'E', 'E'
};

state_q sq = {
    .arr = state_arr,
    .capacity = STATE_Q_SIZE
};

remaing_state msq = {
    .arr = maintenance_arr,
    .capacity = MAINTENANCE_Q_SIZE
};

remaing_state esq = {
    .arr = emergency_arr,
    .capacity = EMERGENCY_Q_SIZE
};

remaing_state isq = {
    .arr = internal_arr,
    .capacity = INTERNAL_Q_SIZE
};

/* All functions below work with sq, msq, esq, or isq.
 * They are intended for serial calls. If main and an ISR share a queue,
 * protect each entire operation with an appropriate critical section.
 * Do not copy a queue object to make an independent queue: its arr pointer
 * would still refer to the original storage.
 */

uint8_t insert_q(queue_t *q, uint8_t value)
{

        uint8_t previous;

        if (q->tail == 0U)
            previous = (uint8_t)(q->capacity - 1U);
        else
            previous = (uint8_t)(q->tail - 1U);
        if (q->arr[previous] == value)
            return 0U;


    if (q->count == q->capacity)
         q->count = q->count % q->capacity;
    q->arr[q->tail] = value;

    q->tail++;
    if (q->tail == q->capacity)
        q->tail = 0U;

    q->count++;
    if(value != '*'|| value != '#'){
    q->pending_reg[value]++;

    }
    return 1U;
}

uint8_t remove_head(queue_t *q)
{
    if (q->count == 0U)
        return 0U;

    uint8_t value = q->arr[q->head];
    q->arr[q->head] = 'E';
    q->head = (uint8_t)((q->head + 1U) % q->capacity);
    q->count--;
    q->pending_reg[value]--;
    return 1U;
}

uint8_t search_element( queue_t *q, uint8_t value)
{
    if (value < 1U)
        return 0U;

    return (q->pending_reg[value] > 0U) ? 1U : 0U;
}

/* Remove the first matching value, preserving order, in one loop. */
uint8_t remove_the_element(queue_t *q, uint8_t value)
{
    if (q->count == 0U)
        return 0U;

    uint8_t found = 0U;
    uint8_t index = q->head;
    uint8_t n;

    for (n = 0U; n < q->count; n++)
    {
        if (found == 0U && q->arr[index] == value)
            found = 1U;

        if (found != 0U && (n + 1U) < q->count)
        {
            uint8_t next = (uint8_t)((index + 1U) % q->capacity);
            q->arr[index] = q->arr[next];
        }

        index = (uint8_t)((index + 1U) % q->capacity);
    }

    if (found == 0U)
        return 0U;

    q->tail = (uint8_t)((q->tail + q->capacity - 1U) % q->capacity);
    q->arr[q->tail] = 'E';
    q->count--;
    q->pending_reg[value]--;
    return 1U;
}

void clear_q(queue_t *q)
{
    memset(q->arr, QUEUE_EMPTY, q->capacity);
    memset(q->pending_reg, 0, sizeof(q->pending_reg));
    q->head = 0U;
    q->tail = 0U;
    q->count = 0U;
}
uint8_t check_q(queue_t *q)
{
    return (q->count == 0U) ? 0 : 1;
}

uint8_t read_head(queue_t *q)
{
    if(q->count>=1)
     return q->arr[q->head];
    else
    return 'E';
}

