/*
 * sw1_sw2.c
 *
 *  Created on: Nov 7, 2026
 *      Author: 16022
 */




#include "sw1_sw2.h"
#include "systick.h"
#include "tm4c123gh6pm.h"

volatile uint32_t diffrence_1 = 0U;
volatile uint32_t diffrence_2 = 0U;
volatile uint8_t duration_ready_1 = 0U;
volatile uint8_t duration_ready_2 = 0U;
volatile uint8_t short_pulse_1 = 0U;
volatile uint8_t short_pulse_2 = 0U;
volatile uint32_t x = 0U;

/* Private to this source file. ISR-shared objects must be volatile. */
static volatile uint8_t count_1 = 0U, count_2 = 0U;
static volatile uint8_t sw1_down = 0U, sw1_up = 0U;
static volatile uint8_t sw2_down = 0U, sw2_up = 0U;
static volatile uint32_t timer_1 = 0U, timer_2 = 0U;
static volatile uint32_t release_1 = 0U, release_2 = 0U;
static volatile uint32_t sampler_1 = 0U, sampler_2 = 0U;

/* Only Buttons_Update uses these sample counters. */
static uint8_t down_1 = 0U, up_1 = 0U;
static uint8_t down_2 = 0U, up_2 = 0U;
static uint8_t rel_1 = 0U, rel_2 = 0U;

static uint8_t deboucing_down(volatile uint32_t *data,
                             volatile uint32_t *icr,
                             volatile uint32_t *imr,
                             uint32_t position,
                             volatile uint8_t *button_press_down,
                             uint8_t *down,
                             uint8_t *up,
                             volatile uint32_t *last_sample,
                             volatile uint8_t *edge_count,
                             volatile uint8_t *short_pulse)
{
    uint32_t now = count_ms;

    if (*button_press_down == 0U)
        return 0U;

    if ((uint32_t)(now - *last_sample) < DEBOUNCE_MS)
        return 0U;

    *last_sample = now;

    if ((*data & position) == 0U)
    {
        *up = 0U;
        if (++(*down) == DEBOUNCE_SAMPLES)
        {
            *down = 0U;
            *button_press_down = 0U;
            *icr = position;
            *imr |= position;
            return 1U;
        }
    }
    else
    {
        *down = 0U;
        if (++(*up) == DEBOUNCE_SAMPLES)
        {
            *up = 0U;
            *button_press_down = 0U;
            *short_pulse = 1U;
            *edge_count = 0U;
            *icr = position;
            *imr |= position;
            return 1U;
        }
    }

    return 0U;
}

static uint8_t deboucing_up(volatile uint32_t *data,
                           volatile uint32_t *icr,
                           volatile uint32_t *imr,
                           uint32_t position,
                           volatile uint8_t *button_press_up,
                           uint8_t *up,
                           volatile uint32_t *last_sample,
                           volatile uint8_t *edge_count)
{
    uint32_t now = count_ms;

    if (*button_press_up == 0U)
        return 0U;

    if ((uint32_t)(now - *last_sample) < DEBOUNCE_MS)
        return 0U;

    *last_sample = now;

    if ((*data & position) != 0U)
    {
        if (++(*up) == DEBOUNCE_SAMPLES)
        {
            *up = 0U;
            *button_press_up = 0U;
            *edge_count = 0U;
            *icr = position;
            *imr |= position;
            return 1U;
        }
    }
    else
    {
        *up = 0U;
    }

    return 0U;
}

void GPIOPortF_Handler(void)
{
    uint32_t status = GPIO_PORTF_MIS_R & (SW1 | SW2);
    uint32_t now = count_ms;

    x = status;
    GPIO_PORTF_IM_R &= ~status;
    GPIO_PORTF_ICR_R = status;

    if ((status & SW1) != 0U)
    {
        sampler_1 = now;
        count_1++;
        if (count_1 == 1U)
        {
            timer_1 = now;
            sw1_down = 1U;
            sw1_up = 0U;
            short_pulse_1 = 0U;
        }
        else
        {
            release_1 = now;
            sw1_up = 1U;
            count_1 = 0U;
        }
    }

    if ((status & SW2) != 0U)
    {
        sampler_2 = now;
        count_2++;
        if (count_2 == 1U)
        {
            timer_2 = now;
            sw2_down = 1U;
            sw2_up = 0U;
            short_pulse_2 = 0U;
        }
        else
        {
            release_2 = now;
            sw2_up = 1U;
            count_2 = 0U;
        }
    }
}

void Buttons_Init(void)
{
    /* Call once during startup, before accepting button input. */
    SYSCTL_RCGCGPIO_R |= 0x20U;
    while ((SYSCTL_PRGPIO_R & 0x20U) == 0U) {}

    GPIO_PORTF_IM_R &= ~(SW1 | SW2);
    GPIO_PORTF_LOCK_R = 0x4C4F434BU;
    GPIO_PORTF_CR_R |= (SW1 | SW2);

    GPIO_PORTF_AMSEL_R &= ~(SW1 | SW2);
    GPIO_PORTF_PCTL_R &= ~0x000F000FU;
    GPIO_PORTF_AFSEL_R &= ~(SW1 | SW2);
    GPIO_PORTF_DIR_R &= ~(SW1 | SW2);
    GPIO_PORTF_PDR_R &= ~(SW1 | SW2);
    GPIO_PORTF_PUR_R |= (SW1 | SW2);
    GPIO_PORTF_DEN_R |= (SW1 | SW2);

    GPIO_PORTF_IS_R &= ~(SW1 | SW2);
    GPIO_PORTF_IBE_R |= (SW1 | SW2);
    GPIO_PORTF_ICR_R = (SW1 | SW2);
    GPIO_PORTF_IM_R |= (SW1 | SW2);

    NVIC_PRI7_R = (NVIC_PRI7_R & 0xFF00FFFFU) | 0x00A00000U;
    NVIC_EN0_R = 1U << 30;
}

void Buttons_Update(void)
{
    uint32_t duration;

    if (deboucing_down(&GPIO_PORTF_DATA_R, &GPIO_PORTF_ICR_R,
                      &GPIO_PORTF_IM_R, SW1, &sw1_down,
                      &down_1, &up_1, &sampler_1,
                      &count_1, &short_pulse_1))
    {
        diffrence_1 = 0U;
    }

    if (deboucing_down(&GPIO_PORTF_DATA_R, &GPIO_PORTF_ICR_R,
                      &GPIO_PORTF_IM_R, SW2, &sw2_down,
                      &down_2, &up_2, &sampler_2,
                      &count_2, &short_pulse_2))
    {
        diffrence_2 = 0U;
    }

    if (sw1_up != 0U)
    {
        /* Snapshot while this button's interrupt is still masked. */
        duration = (uint32_t)(count_ms - timer_1);
        if (deboucing_up(&GPIO_PORTF_DATA_R, &GPIO_PORTF_ICR_R,
                        &GPIO_PORTF_IM_R, SW1, &sw1_up,
                        &rel_1, &sampler_1, &count_1))
        {
            diffrence_1 = duration;
            duration_ready_1 = 1U;
        }
    }

    if (sw2_up != 0U)
    {
        duration = (uint32_t)(count_ms - timer_2);
        if (deboucing_up(&GPIO_PORTF_DATA_R, &GPIO_PORTF_ICR_R,
                        &GPIO_PORTF_IM_R, SW2, &sw2_up,
                        &rel_2, &sampler_2, &count_2))
        {
            diffrence_2 = duration;
            duration_ready_2 = 1U;
        }
    }
}
