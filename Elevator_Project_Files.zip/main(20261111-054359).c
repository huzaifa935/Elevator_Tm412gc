#include <stdint.h>
#include "keypad.h"
#include "systick.h"
#include "sw1_sw2.h"
#include "q.h"
#include "gpio.h"
#include "tm4c123gh6pm.h"
#include "pll.h"

/* ---------------------------------------------------------------------
 * Named constants (no magic numbers in the controller logic)
 * ------------------------------------------------------------------- */
#define FLOOR_MIN            1U
#define FLOOR_MAX            5U
#define FLOOR_TRAVEL_MS      2000U  /* time to travel one floor            */
#define FLOOR_LOOKAHEAD_MS   1800U  /* when to check if next floor is queued*/
#define DOOR_OPEN_MS         5000U  /* door auto-close time                */
#define POSITION_BLINK_MS    250U   /* 2 Hz blink = toggle every 250 ms    */
#define RGB_HALF_PERIOD_MS   500U   /* 1 Hz blink = toggle every 500 ms    */
#define MAINT_HOLD_MS        5000U  /* long-press time for maintenance     */

#define DIR_OFF   0U
#define DIR_UP    1U
#define DIR_DOWN  2U

#define KEY_EMERGENCY_STOP   0U
#define KEY_EMERGENCY_CLEAR  9U
#define KEY_DOOR_OPEN        '*'
#define KEY_DOOR_CLOSE       '#'

#define SW_BOTH_MASK         (SW1 | SW2)
#define KEYPAD_PORT_MASK     0x0FU   /* keypad column lines on Port B */

/* Extra GPIO functions (gpio.h unchanged). Move to gpio.h when possible. */
void Position_LED(uint8_t floor, uint8_t on);
uint8_t Direction_LED(uint8_t direction); /* 0 = OFF, 1 = UP, 2 = DOWN */

extern state_q sq;

/* Debug values, kept public in case another file references them. */
volatile uint32_t last_hold_ms_1 = 0U;
volatile uint32_t last_hold_ms_2 = 0U;

typedef enum
{
    idle = 1,
    move_up,
    move_down,
    maintenance,
    stop
} state;

/* ---------------------------------------------------------------------
 * Module-private controller data
 * ------------------------------------------------------------------- */
static uint8_t  ps = idle;
static uint8_t  ns = idle;
static uint8_t  key = 0U;

static uint32_t blink_timer = 0U;
static uint32_t open_timer = 0U;
static uint32_t move_timer = 0U;
static uint32_t rgb_timer = 0U;

static uint8_t  toggle = 1U;
static uint8_t  door_open = 0U;
static uint8_t  next_floor = 2U;
static uint8_t  present_floor = FLOOR_MIN;
static uint8_t  found_next = 0U;
static uint8_t  floor_checked = 0U;
static uint8_t  move_timer_started = 0U;

static uint8_t  emergency_flag = 0U;
static uint8_t  maintenance_flag = 0U;
static uint8_t  maintenance_sw = 0U;       /* 0 = SW1 started it, 1 = SW2 */
static uint8_t  maintenance_cleared = 0U;  /* queue cleared on entry      */
static uint8_t  maintenance_from = idle;
static uint8_t  maintenance_exit_armed = 0U;
static uint8_t  keypad_wait_release = 0U;

static volatile uint32_t rejected_requests = 0U;

static struct
{
    uint8_t down, candidate, held;
    uint32_t timer;
} button[2];

/* ---------------------------------------------------------------------
 * Hardware access wrappers.
 * Only these three helpers touch registers / other modules' internals.
 * Move them into their driver modules (keypad.c, sw1_sw2.c, q.c).
 * ------------------------------------------------------------------- */
static uint8_t switches_pressed(void)
{
    return (uint8_t)((~GPIO_PORTF_DATA_R) & SW_BOTH_MASK);
}

static uint8_t switches_debounce_done(void)
{
    return (uint8_t)(GPIO_PORTF_IM_R & ~GPIO_PORTF_RIS_R & SW_BOTH_MASK);
}

static uint8_t keypad_is_released(void)
{
    return (uint8_t)(((GPIO_PORTB_IM_R & KEYPAD_PORT_MASK) == KEYPAD_PORT_MASK) &&
                     ((GPIO_PORTB_DATA_R & KEYPAD_PORT_MASK) == KEYPAD_PORT_MASK));
}

static uint8_t queue_has_room(void)
{
    return (uint8_t)(sq.count < sq.capacity);
}

/* ---------------------------------------------------------------------
 * Small single-purpose helpers
 * ------------------------------------------------------------------- */
static uint8_t is_valid_floor(uint8_t floor)
{
    return (uint8_t)(floor >= FLOOR_MIN && floor <= FLOOR_MAX);
}

static uint8_t is_moving(void)
{
    return (uint8_t)(ns == move_up || ns == move_down);
}

static void open_door(void)
{
    door_open = 1U;
    toggle = 1U;
    open_timer = blink_timer = count_ms;
    ns = stop;
}

static void arrive_and_open(void)
{
    remove_the_element(&sq, present_floor);
    Direction_LED(DIR_OFF);
    move_timer_started = 0U;
    open_door();
}

/* from_keypad: a floor key also restarts the door timer if door is open. */
static void add_request(uint8_t floor, uint8_t from_keypad)
{
    if (emergency_flag == 0U && !is_moving() && floor == present_floor)
    {
        open_door();   /* same floor: open door or restart the timer */
        return;
    }

    if (is_valid_floor(floor) && queue_has_room())
        insert_q(&sq, floor);
    else
        rejected_requests++;

    if (from_keypad != 0U && door_open != 0U && emergency_flag == 0U)
        open_timer = count_ms;
}

/* Returns 1 when the door is closed. */
static uint8_t door_service(uint8_t floor)
{
    uint32_t steps;

    if (door_open != 0U && emergency_flag == 0U && maintenance_flag == 0U &&
        (uint32_t)(count_ms - open_timer) >= DOOR_OPEN_MS)
        door_open = 0U;

    if (door_open != 0U)
    {
        steps = (uint32_t)(count_ms - blink_timer) / POSITION_BLINK_MS;
        if (steps != 0U)
        {
            toggle ^= (uint8_t)(steps & 1U);
            blink_timer += steps * POSITION_BLINK_MS;
        }
        blink_led(floor, toggle);   /* external position LED only */
    }
    else
    {
        toggle = 1U;
        Position_LED(floor, 1U);
    }
    return (door_open == 0U) ? 1U : 0U;
}

static void start_trip_to(uint8_t target)
{
    found_next = floor_checked = move_timer_started = 0U;
    if (target > present_floor)
    {
        next_floor = present_floor + 1U;
        ns = move_up;
    }
    else
    {
        next_floor = present_floor - 1U;
        ns = move_down;
    }
    move_timer_started = Direction_LED((ns == move_up) ? DIR_UP : DIR_DOWN);
    if (move_timer_started != 0U)
        move_timer = count_ms;
}

/* ---------------------------------------------------------------------
 * Switch handling (SW1 = floor 1, SW2 = floor 5, 5 s hold = maintenance)
 * ------------------------------------------------------------------- */
static void enter_maintenance(uint8_t sw_index)
{
    maintenance_flag = 1U;
    maintenance_sw = sw_index;
    maintenance_from = ns;
    maintenance_cleared = maintenance_exit_armed = 0U;
    button[0].held = button[1].held = 1U;
    ns = maintenance;
}

static void exit_maintenance(void)
{
    door_open = maintenance_flag = maintenance_cleared = 0U;
    maintenance_exit_armed = 0U;
    button[0].held = button[1].held = 1U;
    keypad_wait_release = 1U;
    ns = idle;
}

static void read_switches(void)
{
    static const uint8_t mask[2] = {SW1, SW2};
    uint8_t raw = switches_pressed();
    uint8_t ready = switches_debounce_done();
    uint8_t i;

    /* Tie-break: SW1 is processed first if both are recognised in one tick. */
    for (i = 0U; i < 2U; i++)
    {
        uint8_t is_maint_sw = (uint8_t)(maintenance_flag != 0U &&
                                        maintenance_sw == i);

        if ((raw & mask[i]) != 0U && button[i].candidate == 0U)
        {
            button[i].candidate = 1U;
            button[i].timer = count_ms;
        }

        if ((ready & mask[i]) != 0U)
        {
            if ((raw & mask[i]) == 0U)          /* confirmed release */
            {
                if (button[i].down != 0U && is_maint_sw)
                    maintenance_exit_armed = 1U;
                button[i].down = button[i].candidate = button[i].held = 0U;
            }
            else if (button[i].down == 0U)      /* confirmed new press */
            {
                button[i].down = 1U;
                button[i].held = maintenance_flag;
                if (maintenance_flag == 0U)
                    add_request((i == 0U) ? FLOOR_MIN : FLOOR_MAX, 0U);
                else if (is_maint_sw && ns == stop && maintenance_exit_armed != 0U)
                    exit_maintenance();
            }
        }

        if (button[i].down != 0U && (raw & mask[i]) != 0U)
        {
            uint32_t held = (uint32_t)(count_ms - button[i].timer);
            if (i == 0U) last_hold_ms_1 = held;
            else         last_hold_ms_2 = held;

            if (held >= MAINT_HOLD_MS && button[i].held == 0U &&
                maintenance_flag == 0U)
                enter_maintenance(i);
        }
    }
}

/* ---------------------------------------------------------------------
 * Travel (one routine for both directions)
 * ------------------------------------------------------------------- */
static void travel_step(uint8_t up)
{
    uint32_t elapsed;

    Position_LED(present_floor, 1U);
    if (Direction_LED(up ? DIR_UP : DIR_DOWN) == 0U)
        return;                              /* relay still switching */

    if (move_timer_started == 0U)
    {
        move_timer = count_ms;
        move_timer_started = 1U;
    }

    elapsed = (uint32_t)(count_ms - move_timer);
    if (elapsed >= FLOOR_LOOKAHEAD_MS && floor_checked == 0U)
    {
        found_next = search_element(&sq, next_floor);
        floor_checked = 1U;
    }

    if (elapsed >= FLOOR_TRAVEL_MS)
    {
        present_floor = next_floor;
        Position_LED(present_floor, 1U);

        /* Recheck: a request may have arrived after the look-ahead check. */
        if (found_next || search_element(&sq, present_floor))
        {
            arrive_and_open();
        }
        else if (up ? (present_floor < FLOOR_MAX) : (present_floor > FLOOR_MIN))
        {
            if (up) next_floor++;
            else    next_floor--;
            move_timer += FLOOR_TRAVEL_MS;
        }
        else
        {
            Direction_LED(DIR_OFF);
            ns = idle;
        }
        found_next = floor_checked = 0U;
    }
}

/* ---------------------------------------------------------------------
 * State handlers
 * ------------------------------------------------------------------- */
static void run_idle_or_stop(void)
{
    Direction_LED(DIR_OFF);
    door_service(present_floor);

    if (emergency_flag != 0U || maintenance_flag != 0U || door_open != 0U)
        return;

    if (check_q(&sq))
    {
        uint8_t target = read_head(&sq);
        if (target == present_floor)
        {
            remove_head(&sq);
            open_door();
        }
        else
            start_trip_to(target);
    }
    else
        ns = idle;
}

static void run_maintenance_entry(void)
{
    uint8_t target;

    if (maintenance_cleared != 0U)
        return;

    target = (maintenance_sw == 0U) ? FLOOR_MIN : FLOOR_MAX;
    clear_q(&sq);
    insert_q(&sq, target);               /* only the maintenance destination */
    maintenance_cleared = 1U;
    emergency_flag = door_open = found_next = floor_checked = 0U;
    rgb_timer = count_ms;

    if (target == present_floor)
    {
        remove_head(&sq);
        Direction_LED(DIR_OFF);
        Position_LED(present_floor, 1U);
        open_door();
        return;
    }

    ns = (target > present_floor) ? move_up : move_down;
    /* Keep elapsed time if already moving that way; a reversal starts a
     * new step from the displayed floor. */
    if (maintenance_from != ns)
    {
        next_floor = (ns == move_up) ? present_floor + 1U : present_floor - 1U;
        move_timer_started = 0U;
        Direction_LED((ns == move_up) ? DIR_UP : DIR_DOWN);
    }
    Position_LED(present_floor, 1U);
}

void state_machine(void)
{
    ps = ns;

    switch (ps)
    {
        case idle:
        case stop:        run_idle_or_stop();       break;
        case move_up:     travel_step(1U);          break;
        case move_down:   travel_step(0U);          break;
        case maintenance: run_maintenance_entry();  break;
        default:          ns = idle;                break;
    }

    /* Onboard RGB: floor colour normally, blinking colour in special modes. */
    if (maintenance_flag != 0U || emergency_flag != 0U)
    {
        uint8_t color = (maintenance_flag != 0U) ? RGB_CYAN : RGB_MAGENTA;
        if ((((uint32_t)(count_ms - rgb_timer) / RGB_HALF_PERIOD_MS) & 1U) != 0U)
            color = RGB_OFF;
        RGB_Set(color);
    }
    else
        Turn_on(present_floor);
}

/* ---------------------------------------------------------------------
 * Keypad handling
 * ------------------------------------------------------------------- */
static void start_emergency(void)
{
    emergency_flag = 1U;
    door_open = move_timer_started = found_next = floor_checked = 0U;
    rgb_timer = count_ms;
    Direction_LED(DIR_OFF);              /* stop at the current floor */
    ns = stop;
}

static void end_emergency(void)
{
    emergency_flag = 0U;
    open_timer = count_ms;               /* normal 5 s door timer restarts */
}

static void handle_key(uint8_t k)
{
    if (is_valid_floor(k))
    {
        if (emergency_flag == 0U)
            add_request(k, 1U);
    }
    else if (k == KEY_DOOR_OPEN || k == KEY_DOOR_CLOSE)
    {
        if (!is_moving())                /* door keys disabled while moving */
        {
            if (k == KEY_DOOR_OPEN) open_door();
            else                    door_open = 0U;
        }
    }
    else if (k == KEY_EMERGENCY_STOP)
    {
        if (emergency_flag == 0U)
            start_emergency();
    }
    else if (k == KEY_EMERGENCY_CLEAR)
    {
        if (emergency_flag != 0U)
            end_emergency();
    }
    /* Keys 6, 7 and 8 have no action. */
}

static void keypad_service(uint8_t was_maintenance)
{
    if (Keypad_GetKey(&key) != 0U && maintenance_flag == 0U &&
        was_maintenance == 0U && keypad_wait_release == 0U)
        handle_key(key);

    if (keypad_wait_release != 0U && keypad_is_released())
        keypad_wait_release = 0U;
}

/* ---------------------------------------------------------------------
 * main: initialise modules and run the non-blocking loop
 * ------------------------------------------------------------------- */
int main(void)
{
    Keypad_Init();
    Buttons_Init();
    pll_configure();
    SysTick_Init();
    PortF_init();
    clear_q(&sq);
    Position_LED(FLOOR_MIN, 1U);
    Turn_on(FLOOR_MIN);

    while (1)
    {
        uint8_t was_maintenance = maintenance_flag;
        Buttons_Update();
        read_switches();
        keypad_service(was_maintenance);
        /* Release reports are consumed. */
        duration_ready_1 = duration_ready_2 = 0U;
        state_machine();
    }
}
