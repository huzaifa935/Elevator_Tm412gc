/*
 * gpio.c
 *
 *  Created on: Nov 4, 2026
 *      Author: 16022
 */


#include "tm4c123gh6pm.h"
#include "gpio.h"
#include "stdint.h"
#include "q.h"
#include "systick.h"

#define SW1          (1U << 4)  /* PF4: onboard switch 1. */
#define SW2          (1U << 0)  /* PF0: onboard switch 2. */
uint8_t count_1=0;
uint8_t count_2=0;
uint32_t count_ms_1 = 0;
uint32_t count_ms_2 = 0;

/* External floor LEDs: PC4, PC5, PC6, PC7, PD6; one resistor per LED.
 * Proposed single-relay wiring (actual relay details have not been supplied):
 * PA2 -> compatible relay module IN; PA3 -> COM;
 * NO -> resistor -> UP LED -> GND; NC -> resistor -> DOWN LED -> GND.
 * Both LEDs are disabled with PA3 LOW while the relay changes contacts.
 * Every direction LED current path therefore includes the relay contacts.
 */
#ifndef RELAY_ACTIVE_LOW
#define RELAY_ACTIVE_LOW 1U
#endif
#ifndef RELAY_SETTLE_MS
/* PROVISIONAL: match to maximum operate/release + bounce time, with margin.
 * The no-wrong-LED guarantee depends on the bound matching the actual module.
 * The module IN must accept 3.3 V logic; PA2 must not drive a bare coil.
 */
#define RELAY_SETTLE_MS 25U
#endif

static uint8_t direction = 0U, coil = 0U, settling = 1U;
static uint32_t relay_timer = 0U;

void PortF_init(void)
{
    /* Enable Port F clock */
    SYSCTL_RCGCGPIO_R |= (1U << 5);
    while ((SYSCTL_PRGPIO_R & (1U << 5)) == 0U)
    {
    }

    /* Mask switch interrupts during configuration */
    GPIO_PORTF_IM_R &= ~0x11U;

    /* Unlock PF0 for SW2 */
    GPIO_PORTF_LOCK_R = 0x4C4F434BU;
    GPIO_PORTF_CR_R |= 0x1FU;

    /* PF0�PF4: digital GPIO */
    GPIO_PORTF_AFSEL_R &= ~0x1FU;
    GPIO_PORTF_PCTL_R  &= ~0x000FFFFFU;
    GPIO_PORTF_AMSEL_R &= ~0x1FU;

    /* SW1 = PF4, SW2 = PF0: inputs */
    GPIO_PORTF_DIR_R &= ~0x11U;

    /*
     * RGB LED:
     * PF1 = Red
     * PF2 = Blue
     * PF3 = Green
     */
    GPIO_PORTF_DATA_R &= ~0x0EU;  /* Initially OFF */
    GPIO_PORTF_ODR_R  &= ~0x0EU;  /* Push-pull outputs */
    GPIO_PORTF_DIR_R  |=  0x0EU;  /* RGB pins are outputs */

    /* Pull-ups for switches; no pulls on RGB pins */
    GPIO_PORTF_PDR_R &= ~0x1FU;
    GPIO_PORTF_PUR_R &= ~0x0EU;
    GPIO_PORTF_PUR_R |=  0x11U;

    /* Enable digital function for switches and RGB */
    GPIO_PORTF_DEN_R |= 0x1FU;

    /* SW1 and SW2: both-edge interrupts */
    GPIO_PORTF_IS_R  &= ~0x11U;
    GPIO_PORTF_IBE_R |=  0x11U;
    /* IEV is ignored when IBE = 1 */

    /* Clear pending flags and enable switch interrupts */
    GPIO_PORTF_ICR_R = 0x11U;
    GPIO_PORTF_IM_R |= 0x11U;

    /* Enable Port F interrupt: IRQ 30 */
    NVIC_EN0_R = (1U << 30);

    /* Added outputs; keypad pins and switch debounce logic are unchanged. */
    SYSCTL_RCGCGPIO_R |= 0x0DU; /* A, C, D. */
    while ((SYSCTL_PRGPIO_R & 0x0DU) != 0x0DU) {}
    GPIO_PORTC_DATA_R &= ~0xF0U;
    GPIO_PORTC_AFSEL_R &= ~0xF0U;
    GPIO_PORTC_AMSEL_R &= ~0xF0U;
    GPIO_PORTC_PCTL_R &= ~0xFFFF0000U;
    GPIO_PORTC_ODR_R &= ~0xF0U;
    GPIO_PORTC_DIR_R |= 0xF0U;
    GPIO_PORTC_DEN_R |= 0xF0U;
    GPIO_PORTD_DATA_R &= ~0x40U;
    GPIO_PORTD_AFSEL_R &= ~0x40U;
    GPIO_PORTD_AMSEL_R &= ~0x40U;
    GPIO_PORTD_PCTL_R &= ~0x0F000000U;
    GPIO_PORTD_ODR_R &= ~0x40U;
    GPIO_PORTD_DIR_R |= 0x40U;
    GPIO_PORTD_DEN_R |= 0x40U;

    GPIO_PORTA_DATA_R &= ~0x0CU; /* PA3 LOW: both direction LEDs OFF. */
    if (RELAY_ACTIVE_LOW != 0U) GPIO_PORTA_DATA_R |= 0x04U;
    GPIO_PORTA_AFSEL_R &= ~0x0CU;
    GPIO_PORTA_AMSEL_R &= ~0x0CU;
    GPIO_PORTA_PCTL_R &= ~0x0000FF00U;
    GPIO_PORTA_ODR_R &= ~0x0CU;
    GPIO_PORTA_DIR_R |= 0x0CU;
    GPIO_PORTA_DEN_R |= 0x0CU;
    direction = coil = 0U;
    settling = 1U;
    relay_timer = count_ms;
}

static uint8_t floor_to_color(uint8_t floor)
{
    switch (floor)
    {
        /* Floor colours from the professor's block diagram. */
        case 1U: return RGB_WHITE;
        case 2U: return RGB_YELLOW;
        case 3U: return RGB_GREEN;
        case 4U: return RGB_BLUE;
        case 5U: return RGB_RED;
        case 6U: return RGB_MAGENTA;
        default: return RGB_OFF;
    }
}

void RGB_Set(uint8_t color)
{
    GPIO_PORTF_DATA_R = (GPIO_PORTF_DATA_R & ~0x0EU) | (color & 0x0EU);
}

void Turn_off(uint8_t floor)
{
    (void)floor;

    GPIO_PORTF_DATA_R &= ~0x0EU;
}

void Turn_on(uint8_t floor)
{
    uint8_t color = floor_to_color(floor);

    if (color == RGB_OFF)
        return;

    GPIO_PORTF_DATA_R =
        (GPIO_PORTF_DATA_R & ~0x0EU) |
        ((uint32_t)color & 0x0EU);
}

void Position_LED(uint8_t floor, uint8_t on)
{
    uint32_t pc = 0U, pd = 0U;
    if (on != 0U && floor >= 1U && floor <= 4U)
        pc = 1U << (floor + 3U);
    else if (on != 0U && floor == 5U)
        pd = 0x40U;
    /* Clear the previous port first so two floor LEDs cannot be on. */
    if (pc != 0U)
    {
        GPIO_PORTD_DATA_R &= ~0x40U;
        GPIO_PORTC_DATA_R = (GPIO_PORTC_DATA_R & ~0xF0U) | pc;
    }
    else
    {
        GPIO_PORTC_DATA_R &= ~0xF0U;
        GPIO_PORTD_DATA_R = (GPIO_PORTD_DATA_R & ~0x40U) | pd;
    }
}

void blink_led(uint8_t floor, uint8_t flag)
{
    Position_LED(floor, flag); /* Door blink belongs to the external LED. */
}

uint8_t Direction_LED(uint8_t requested)
{
    uint8_t new_coil;
    if (requested > 2U) requested = 0U;
    if (requested != direction)
    {
        GPIO_PORTA_DATA_R &= ~0x08U; /* Blank BOTH LEDs BEFORE switching. */
        direction = requested;
        if (requested != 0U)
        {
            new_coil = (requested == 1U) ? 1U : 0U;
            if (new_coil != coil)
            {
                coil = new_coil;
                if ((coil != 0U) != (RELAY_ACTIVE_LOW != 0U))
                    GPIO_PORTA_DATA_R |= 0x04U;
                else
                    GPIO_PORTA_DATA_R &= ~0x04U;
                relay_timer = count_ms;
                settling = 1U;
            }
        }
    }
    if (settling != 0U && (uint32_t)(count_ms - relay_timer) >= RELAY_SETTLE_MS)
        settling = 0U;
    if (requested != 0U && settling == 0U)
    {
        GPIO_PORTA_DATA_R |= 0x08U;
        return 1U;
    }
    GPIO_PORTA_DATA_R &= ~0x08U;
    return 0U;
}
