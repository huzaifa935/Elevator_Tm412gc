#ifndef SYSTICK_H_
#define SYSTICK_H_

#include <stdint.h>

/* Defined once in systick.c; incremented by the timer ISR. */
extern volatile uint32_t count_ms;

/* Assumes a 16 MHz system clock and produces a 1 ms tick. */
void SysTick_Init(void);
void SysTick_Handler(void);

#endif /* SYSTICK_H_ */
