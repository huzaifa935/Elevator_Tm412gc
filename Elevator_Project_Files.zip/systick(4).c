#include "systick.h"
#include "tm4c123gh6pm.h"

volatile uint32_t count_ms = 0U;

void SysTick_Handler(void)
{
    count_ms++;
}

void SysTick_Init(void)
{
    NVIC_ST_CTRL_R = 0U;

    NVIC_ST_RELOAD_R = 79999U;
    NVIC_ST_CURRENT_R = 0U;
    NVIC_ST_CTRL_R = 0x07U;
}
